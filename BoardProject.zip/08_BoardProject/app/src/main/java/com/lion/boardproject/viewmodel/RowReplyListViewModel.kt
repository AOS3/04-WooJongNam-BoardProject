package com.lion.boardproject.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.lion.boardproject.fragment.BoardListFragment

class RowReplyListViewModel(val boardListFragment: BoardListFragment) : ViewModel(){
    // textViewRowReplyListContent - text
    val textViewRowReplyListContentText = MutableLiveData("")
    // textViewRowReplyListNickName - text
    val textViewRowReplyListNickNameText = MutableLiveData("")
}