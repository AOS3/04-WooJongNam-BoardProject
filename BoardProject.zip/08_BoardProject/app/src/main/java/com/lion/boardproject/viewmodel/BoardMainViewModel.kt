package com.lion.boardproject.viewmodel

import androidx.lifecycle.ViewModel
import com.lion.boardproject.fragment.BoardMainFragment

class BoardMainViewModel(val boardMainFragment: BoardMainFragment) : ViewModel() {
}