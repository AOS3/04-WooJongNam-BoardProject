package com.lion.boardproject.fragment

import android.content.DialogInterface
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.core.view.children
import androidx.core.view.isVisible
import androidx.databinding.DataBindingUtil
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.lion.boardproject.BoardActivity
import com.lion.boardproject.R
import com.lion.boardproject.databinding.FragmentBoardReadBinding
import com.lion.boardproject.model.BoardModel
import com.lion.boardproject.model.ReplyModel
import com.lion.boardproject.repository.BoardRepository
import com.lion.boardproject.service.BoardService
import com.lion.boardproject.util.ReplyState
import com.lion.boardproject.viewmodel.BoardReadViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.async
import kotlinx.coroutines.launch

class BoardReadFragment(val boardMainFragment: BoardMainFragment) : Fragment() {

    lateinit var fragmentBoardReadBinding: FragmentBoardReadBinding
    lateinit var boardActivity: BoardActivity

    // 현재 글의 문서 id를 담을 변수
    lateinit var boardDocumentId:String

    // 글 데이터를 담을 변수
    lateinit var boardModel:BoardModel

    // 댓글 리스트를 담을 리스트
    lateinit var replyListModel:MutableList<ReplyModel>

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        fragmentBoardReadBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_board_read, container, false)
        fragmentBoardReadBinding.boardReadViewModel = BoardReadViewModel(this@BoardReadFragment)
        fragmentBoardReadBinding.lifecycleOwner = this@BoardReadFragment

        boardActivity = activity as BoardActivity

        // 이미지 뷰를 안보이는 상태로 설정한다.
        fragmentBoardReadBinding.imageViewBoardRead.isVisible = false

        // arguments의 값을 변수에 담아주는 메서드를 호출한다.
        gettingArguments()
        // 툴바를 구성하는 메서드를 호출한다.
        settingToolbar()
        // 글 데이터를 가져와 보여주는 메서드를 호출한다.
        settingBoardData()
        //댓글 테스트
        testListView()
        settingReplyData()

        return fragmentBoardReadBinding.root
    }
    fun testListView(){
        val dataArray = arrayOf(
            "댓글1", "댓글2", "댓글3", "댓글4", "댓글5",
            "댓글6", "댓글7", "댓글8", "댓글9", "댓글10",
            "댓글11", "댓글12", "댓글13", "댓글14", "댓글15",
            "댓글16", "댓글17", "댓글18", "댓글19", "댓글20",
        )
        // 두 번째 : 항목 하나의 View를 만들기 위한 layout 파일
        // 세 번째 : 문자열을 설정할 TextView 의 id
        fragmentBoardReadBinding.apply {
            listView1.adapter = ArrayAdapter<String>(
                boardActivity,
                R.layout.row_reply_list,
                R.id.textViewRowReplyContent,
                dataArray
            )

        }


    }
    // 이전 화면으로 돌아가는 메서드
    fun movePrevFragment(){
        boardMainFragment.removeFragment(BoardSubFragmentName.BOARD_WRITE_FRAGMENT)
        boardMainFragment.removeFragment(BoardSubFragmentName.BOARD_READ_FRAGMENT)
    }

    // 툴바를 구성하는 메서드
    fun settingToolbar(){
        fragmentBoardReadBinding.apply {
            // 메뉴를 보이지 않게 설정한다.
            toolbarBoardRead.menu.children.forEach {
                it.isVisible = false
            }

            toolbarBoardRead.setOnMenuItemClickListener {
                when(it.itemId){
                    R.id.menuItemBoardReadModify -> {
                        // 글의 문서 번호를 전달한다.
                        val dataBundle = Bundle()
                        dataBundle.putString("boardDocumentId", boardDocumentId)
                        boardMainFragment.replaceFragment(BoardSubFragmentName.BOARD_MODIFY_FRAGMENT, true, true, dataBundle)
                    }
                    R.id.menuItemBoardReadDelete -> {
                        val builder = MaterialAlertDialogBuilder(boardActivity)
                        builder.setTitle("글 삭제")
                        builder.setMessage("삭제시 복구할 수 없습니다")
                        builder.setNegativeButton("취소", null)
                        builder.setPositiveButton("삭제"){ dialogInterface: DialogInterface, i: Int ->
                            proBoardDelete()
                        }
                        builder.show()
                    }
                }
                true
            }
        }
    }

    // arguments의 값을 변수에 담아준다.
    fun gettingArguments(){
        boardDocumentId = arguments?.getString("boardDocumentId")!!
    }
    // 댓글 데이터를 가져와 보여주는 메서드
//    fun testReply(){
//        CoroutineScope(Dispatchers.Main).launch {
//            val work1 = async(Dispatchers.IO){
//                BoardRepository.selectReplyDataAll()
//            }
//            val boardVO = work1.await()
//            //Log.d("test111", "${boardVO}")
//
//
//
//        }
//    }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    fun addReply() {

        fragmentBoardReadBinding.apply {
            // 게시판 구분값


            // 게시글 내용
            //var replyText = boardReadViewModel?.textFieldAddReplyText?.value!!
            var replyText = textField1.editText?.text
            Log.d("test111","replyText= ${replyText}")
            var replyBoardId = boardDocumentId
            var replyNickName = boardActivity.loginUserNickName
            var replyTimeStamp = System.nanoTime()
            var replyState = ReplyState.REPLY_STATE_NORMAL
            // 업로드
            CoroutineScope(Dispatchers.Main).launch {
                val replyModel = ReplyModel()
                replyModel.replyDocumentId ="tempDocID2"
                replyModel.replyNickName = replyNickName
                replyModel.replyText = replyText.toString()
                replyModel.replyBoardId = replyBoardId
                replyModel.replyTimeStamp = replyTimeStamp

                replyModel.replyState = replyState
                Log.d("test111","service-addReplyData - replyModel = ${replyModel.toString()}")
                // 저장한다.
                val work2 = async(Dispatchers.IO){
                    BoardService.addReplyData(replyModel)
                }
                val documentId = work2.await()
                Log.d("test111", documentId)

            }

        }
    }
    ////////////////////////////////////////////////////////////////////////////////////
    //댓글 데이터를 가져와 보여주는 메서드
    fun settingReplyData(){
        Log.d("test111","BoardReadFragment - settingReplyData()서버에서 데이터를 가져온다" )
        // 서버에서 데이터를 가져온다.
        CoroutineScope(Dispatchers.Main).launch {
            val work1 = async(Dispatchers.IO){
                BoardService.gettingReplyList(boardDocumentId)
            }
            replyListModel = work1.await()
            Log.d("test111","replyListModel.size = ${replyListModel.size}")
            replyListModel.forEach{
                Log.d("test111", "${it.replyText}")
            }
            Log.d("test111","BoardReadFragment - settingReplyData() courutin AWAIT" )




        }
        Log.d("test111","BoardReadFragment - settingBoardData() courutin end" )
    }


        // 글 데이터를 가져와 보여주는 메서드
    fun settingBoardData(){
        Log.d("test111","BoardReadFragment - settingBoardData()서버에서 데이터를 가져온다" )
        // 서버에서 데이터를 가져온다.
        CoroutineScope(Dispatchers.Main).launch {
            val work1 = async(Dispatchers.IO){
                BoardService.selectBoardDataOneById(boardDocumentId)
            }
            boardModel = work1.await()
            Log.d("test111","BoardReadFragment - settingBoardData() courutin AWAIT" )

            fragmentBoardReadBinding.apply {
                boardReadViewModel?.textFieldBoardReadTitleText?.value = boardModel.boardTitle
                boardReadViewModel?.textFieldBoardReadTextText?.value = boardModel.boardText
                boardReadViewModel?.textFieldBoardReadTypeText?.value = boardModel.boardTypeValue.str
                boardReadViewModel?.textFieldBoardReadNickName?.value = boardModel.boardWriterNickName

                // 작성자와 로그인한 사람이 같으면 메뉴를 보기에 한다.
                if(boardModel.boardWriteId == boardActivity.loginUserDocumentId){
                    toolbarBoardRead.menu.children.forEach {
                        it.isVisible = true
                    }
                }
            }
            Log.d("test111","BoardReadFragment - settingBoardData() courutin MID" )
            // 첨부 이미지가 있다면
            if(boardModel.boardFileName != "none"){
                val work1 = async(Dispatchers.IO) {
                    // 이미지에 접근할 수 있는 uri를 가져온다.
                    BoardService.gettingImage(boardModel.boardFileName)
                }

                val imageUri = work1.await()
                boardActivity.showServiceImage(imageUri, fragmentBoardReadBinding.imageViewBoardRead)
                fragmentBoardReadBinding.imageViewBoardRead.isVisible = true
            }
        }
        Log.d("test111","BoardReadFragment - settingBoardData() courutin end" )
    }

    // 글 삭제 처리 메서드
    fun proBoardDelete(){
        CoroutineScope(Dispatchers.Main).launch {
            // 만약 첨부 이미지가 있다면 삭제한다.
            if(boardModel.boardFileName != "none"){
                val work1 = async(Dispatchers.IO){
                    BoardService.removeImageFile(boardModel.boardFileName)
                }
                work1.join()
            }
            // 글 정보를 삭제한다.
            val work2 = async(Dispatchers.IO){
                BoardService.deleteBoardData(boardDocumentId)
            }
            work2.join()
            // 글 목록 화면으로 이동한다.
            boardMainFragment.removeFragment(BoardSubFragmentName.BOARD_READ_FRAGMENT)
        }
    }

}